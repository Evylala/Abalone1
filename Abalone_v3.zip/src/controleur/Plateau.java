package controleur;

import java.awt.Color;
import java.util.ArrayList;

public class Plateau {
	
	private ArrayList<Case> listeCases;
	int NB_LIG = 9;
	int NB_COL_MAX = 9;
	int NOMBRE_CASES = 61;
	
	public Plateau() {
		this.listeCases = new ArrayList<Case>();
	}
	
	
	public ArrayList<Case> getListeCases() {
		return this.listeCases;
	}
	
	public void setListeCases(ArrayList<Case> listeCases) {
		this.listeCases = listeCases;
	}
	
	/**
	 * Cr�e la liste des boules et le plateau de d�part
	 */
	public void initialiserPlateau() {
		for (int i=0; i<NOMBRE_CASES; i++) {
			if ((i >= 0 && i <= 10) || (i >= 13 && i <= 15)) {
				this.listeCases.add(new Case(TypeCase.BOULE_BLANCHE));
			} else if ((i>=45 && i<=47) || (i>=50 && i<=60)) {
				this.listeCases.add(new Case(TypeCase.BOULE_NOIRE));
			} else {
				this.listeCases.add(new Case(TypeCase.VIDE));
			}
		}
		
		this.afficher();
	}
	
	/**
	 * Affichage du plateau (variable tableauPlateau)
	 */
	public void afficher() {
		int decalage = 0;
		int num_lig = 0;
		
		for (int i=0; i<this.listeCases.size(); i++) {
			if (num_lig != getNumeroLigneByIndex(i)) {
				if (num_lig != 1) {
					for (int j=0; j<decalage; j++) {
						System.out.print(" ");
					}
					
				}
				System.out.println();
				num_lig = getNumeroLigneByIndex(i);
				decalage = getDecalage(getNumeroLigneByIndex(i));
				for (int j=0; j<decalage; j++) {
					System.out.print(" ");
				}
			}
			System.out.print(" " + this.listeCases.get(i).toString());
		}
		System.out.println();
	}
	
	public int getIndexCase(int num_lig, int num_col) {
		int index=0;
		int i;
		
		for (i=1;i<num_lig;i++) {
			index += getNombreCasesSurLigne(i);
		}
		index += num_col - 1;
		
		return index;
	}
	
	public int getNombreCasesSurLigne(int num_lig) {
		if (num_lig >=1 && num_lig <=5) {
			return num_lig + 4;
		} else {
			return getNombreCasesSurLigne(10 - num_lig);
		}
	}
	
	public int getNumeroLigneByIndex(int index) {
		for (int i=1; i<=NB_LIG+1; i++) {
			if (index < getIndexCase(i, 1)) {
				return i-1;
			}
		}
		
		return 0;
	}
	
	public int getDecalage(int num_lig) {
		if (num_lig >= 1 && num_lig <= 5) {
			return 5 - num_lig;
		} else {
			return num_lig - 5;
		}
	}
	
	public ArrayList<Integer> getIndexCasesNotreCouleur(Color couleur) {
		TypeCase type = null;
		ArrayList<Integer> listeIndexCases = new ArrayList<Integer>();
		
		if (couleur == Color.WHITE) {
			type = TypeCase.BOULE_BLANCHE;
		} else {
			type = TypeCase.BOULE_NOIRE;
		}
		
		for (int i=0; i<this.listeCases.size(); i++) {
			if (this.listeCases.get(i).getType() == type) {
				listeIndexCases.add(i);
			}
		}
		
		return listeIndexCases;
	}

}
