package controleur;

import java.util.ArrayList;

public class Machine extends Joueur {
	
	public Machine (String nom, Deplacement deplLigne, Deplacement deplFleche) {
		super(nom, deplLigne, deplFleche);
	}

	@Override
	public void deplacer(Plateau p) {
		boolean deplacementOK = false;
		Deplacement deplacement = this.deplacementEnLigne;
		TypeDirection direction = null;
		ArrayList<Integer> listeCasesIA = p.getIndexCasesNotreCouleur(this.getCouleur());
		
		while (!deplacementOK) {
			for (Integer i : listeCasesIA) {
				for (int j=0; j<6; j++) {
					System.out.println("j : "+j);
					direction = getDirection(j);
					deplacementOK = deplacement.deplacementPossible(i, direction, 1, this);
					if (deplacementOK) {
						break;
					}
				}
				if (deplacementOK) {
					break;
				}
			}
		}
	}
	
	public TypeDirection getDirection(int index) {
		switch(index) {
			case 0:
				return TypeDirection.BAS_DROIT;
			case 1:
				return TypeDirection.BAS_GAUCHE;
			case 2:
				return TypeDirection.DROITE;
			case 3: 
				return TypeDirection.GAUCHE;
			case 4:
				return TypeDirection.HAUT_DROIT;
			case 5: 
				return TypeDirection.HAUT_GAUCHE;
			default :
				return null;
				
		}
	}
	
}
