package controleur;

public enum TypeDeplacement {
	EN_FLECHE,
	EN_LIGNE
}
