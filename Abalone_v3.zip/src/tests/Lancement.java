package tests;

import controleur.*;

public class Lancement {
	
	public static void main(String[] args) {
		Plateau plateau = new Plateau();
		Deplacement deplacementLigne = new DeplacementEnLigne(plateau);
		Deplacement deplacementFleche = new DeplacementEnFleche(plateau);
		
		Joueur homme = new Homme("Evy", deplacementLigne, deplacementFleche);
		Joueur homme2 = new Homme("Thomas", deplacementLigne, deplacementFleche);
		Joueur machine = new Machine("Champion", deplacementLigne, deplacementFleche);
		
		
		Partie partie = new Partie(homme, machine, plateau);
		
		System.out.println("---------------------------------------- Bienvenue sur le jeu Abalone ------------------------------------------\n\n");
		System.out.println("Vous poss�dez les boules \"O\"\n\n ");
		
		partie.lancerPartie();
		
	}
}
