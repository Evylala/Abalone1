package controleur;

public enum Deplacement {
	HAUT_GAUCHE,
	HAUT_DROIT,
	DROITE,
	GAUCHE,
	BAS_GAUCHE,
	BAS_DROIT
}
