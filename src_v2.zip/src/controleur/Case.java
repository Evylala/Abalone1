package controleur;

public class Case {
	
	TypeCase type;
	Boule boule;
	
	public Case(TypeCase type, Boule boule) {
		this.type = type;
		this.boule = boule;
	}
	
	public TypeCase getType() {
		return this.type;
	}
	
	public Boule getBoule() {
		return this.boule;
	}
	
	public void setType(TypeCase type) {
		this.type = type;
	}
	
	public void setBoule(Boule boule) {
		this.boule = boule;
	}
	
	public boolean caseVide() {
		return this.type == TypeCase.VIDE;
	}
	
	public boolean caseHorsPlateau() {
		return this.type == TypeCase.NON_JOUABLE;
	}
	
	public String toString() {
		if (this.type == TypeCase.VIDE) {
			return "-";
				
		} else if (this.type == TypeCase.NON_JOUABLE) {
			return "";
		} else {
			return this.boule.toString();
		}
	}
}
