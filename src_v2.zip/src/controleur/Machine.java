package controleur;

public class Machine extends Joueur {
	
	public Machine (String nom, Regles regles) {
		super(nom, regles);
	}

	@Override
	public void deplacer(Plateau p) {
	}
}
