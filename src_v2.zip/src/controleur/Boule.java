package controleur;

import java.awt.Color;
import java.awt.Point;

public class Boule {
	
	protected Color colour;
	protected Point position;

	public Boule(Color c, Point p) {
		this.colour = c;
		this.position = p;
	}
	
	public Color getCouleur() {
		return this.colour;
	}
	
	public Point getPosition() {
		return this.position;
	}
	
	public void setPosition(Point newPosition) {
		this.position = newPosition;
	}
	
	public void setColor(Color couleur) {
		this.colour = couleur;
	}
	
	public int getX() {
		return this.position.x;
	}
	
	public int getY() {
		return this.position.y;
	}
	
	public String toString() {
		if (this.colour == Color.WHITE) {
			return "X";
		} else {
			return "O";
		}
	}
	
	@Override
	public boolean equals(Object obj) {
		
        if (obj==this) {
            return true;
        }
 
        // V�rification du type du param�tre
        if (obj instanceof Boule) {
            // V�rification des valeurs des attributs
            Boule other = (Boule) obj;
 
            return this.getCouleur() == other.getCouleur() && this.getX() == other.getX() && this.getY() == other.getY();
            
        }
 
        return false;
		
	}

}
