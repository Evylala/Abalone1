package controleur;

import java.awt.Color;
import java.awt.Point;
import java.util.Scanner;

public class Homme extends Joueur {

	Scanner sc = new Scanner(System.in);
	
	public Homme(String nom, Regles regles) {
		super(nom, regles);
	}

	@Override
	public void deplacer(Plateau plateau) {
		boolean deplacementOK = false;
		int nbBoules = 0;
		Boule boule = null;
		Deplacement deplacement = null;
		
		while(deplacementOK == false) {
			
			System.out.println(("Au tour de "+nom));
			nbBoules = this.choixNombreBoulesADeplacer();
			
			boule = this.choixBoule();
			while(!plateau.bouleExiste(boule)) {
				System.out.println("Aucune boule � vous � cette position, veuillez refaire votre choix,");
				boule = this.choixBoule();
			}
			
			deplacement = this.choixDeplacement();
			
			if (this.regles.deplacementEffectue(plateau.getListeBoules(), boule, deplacement, nbBoules)) {
				System.out.println("D�placement termin�");
				if (regles.getBouleAdversaireSortie()) {
					this.ajoutPoint();
				}
				deplacementOK = true;
					
			} else {
				System.out.println(this.regles.getMessageErreur());
			}
		}
  	}
	
	public int choixNombreBoulesADeplacer() {
		int nbBoules = 0;
		System.out.println("Combien de boules souhaitez-vous d�placer (Entre 1 et 3):");
		nbBoules = sc.nextInt();
		while (nbBoules<1 || nbBoules >3) {
			System.out.println("Saisie invalide");
			System.out.println("Combien de boules souhaitez-vous d�placer (Entre 1 et 3):");
			nbBoules = sc.nextInt();
		}
		
		return nbBoules;
	}
	
	public Boule choixBoule() {
		
		int x = 0;
		int y = 0;
		
		System.out.println("Saisissez les coordonn�es des boules\nX (Entre 0 et 8):");
		x = sc.nextInt();
		while (x<0 || x>8) {
			System.out.println("Coordonn�e X invalide");
			System.out.println("Resaissez X (Entre 0 et 8):");
			x = sc.nextInt();
		}
		System.out.println("Y (Entre 0 et 16):");
		y = sc.nextInt();
		while (y<0 || y>16) {
			System.out.println("Coordonn�e Y invalide");
			System.out.println("Resaissez Y (Entre 0 et 16) :");
			y = sc.nextInt();
		}
		
		
		y = Conversion.getYFromTableauToListe(y);
		x = Conversion.getXFromTableauToListe(x, y);
		
		System.out.println(x);
		System.out.println(y);
		
		return new Boule(Color.BLACK, new Point(x, y));
	}
	
	public Deplacement choixDeplacement() {
		int choix = 0;
		Deplacement deplacement = null;
		
		System.out.println("Saisissez le d�placement souhait�");
		System.out.println("1 : HAUT_GAUCHE, 2 : HAUT_DROIT, 3 : DROITE, 4 : GAUCHE, 5 : BAS_GAUCHE, 6 : BAS_DROIT");
		choix = sc.nextInt();
		
		while (choix>6 || choix<1) {
			System.out.println("Choix incorrect, resaisissez,");
			System.out.println("1 : HAUT_GAUCHE, 2 : HAUT_DROIT, 3 : DROITE, 4 : GAUCHE, 5 : BAS_GAUCHE, 6 : BAS_DROIT");
			choix = sc.nextInt();
		}
		
		switch (choix) {
			case 1 :
				deplacement = Deplacement.HAUT_GAUCHE;
				break;
			case 2 :
				deplacement = Deplacement.HAUT_DROIT;
				break;
			case 3 :
				deplacement = Deplacement.DROITE;
				break;
			case 4 : 
				deplacement = Deplacement.GAUCHE;
				break;
			case 5 :
				deplacement = Deplacement.BAS_GAUCHE;
				break;
			case 6 :
				deplacement = Deplacement.BAS_DROIT;
				break;
		}
		
		return deplacement;
	}
	
}

