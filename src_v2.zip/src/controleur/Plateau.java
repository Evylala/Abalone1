package controleur;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;

public class Plateau {
	
	private ArrayList<Boule> listeBoules;
	private Case tableauPlateau[][];
	int NB_LIG = 9;
	int NB_COL = 17;
	
	public Plateau() {
		this.listeBoules = new ArrayList<Boule>();
		this.tableauPlateau = new Case[NB_LIG][NB_COL];
	}
	
	public Case[][] getTabPlateau() {
		return this.tableauPlateau;
	}
	
	public ArrayList<Boule> getListeBoules() {
		return this.listeBoules;
	}
	
	public void setTabPlateau(Case[][] tabPlateau) {
		this.tableauPlateau = tabPlateau;
	}
	
	public void setListeBoules(ArrayList<Boule> listeBoules) {
		this.listeBoules = listeBoules;
	}
	
	public void ajouterBoule(Boule b) {
		this.listeBoules.add(b);
	}
	
	public void retirerBoule(Boule b) {
		this.listeBoules.remove(b);
	}
	
	public boolean bouleExiste(Boule boule) {
		System.out.println(boule.getCouleur());
		return this.listeBoules.contains(boule);
	}
	/**
	 * Cr�e la liste des boules et le plateau de d�part
	 */
	public void initialiserPlateau() {
		
		int bouleY = 0;
		int bouleX = 0;
		
		/* Cr�ation des boules en miroir, la coordonn�e en Y allant de -4 � 4
		 * L'origine se trouve au milieu � gauche
		 */
		for (int x=0; x<6; x++) {
			for (int y=2; y<=4; y++) {
				if (y==2) {
					if (x>=2 && x<=4) {
						this.listeBoules.add(new Boule(Color.WHITE, new Point(x, y)));
						this.listeBoules.add(new Boule(Color.BLACK, new Point(x, -y)));
					}
				} else {
					if (y==3) {
						this.listeBoules.add(new Boule(Color.WHITE, new Point(x, y)));
						this.listeBoules.add(new Boule(Color.BLACK, new Point(x, -y)));
					} else {
						if (x<5) {
							this.listeBoules.add(new Boule(Color.WHITE, new Point(x, y)));
							this.listeBoules.add(new Boule(Color.BLACK, new Point(x, -y)));
						}
					}
				}
			}
			
		}
		int decalage = 0;
		// Cr�ation du plateau
		for (int i=0; i<NB_LIG; i++) {
			
			// D�calage pour avoir un format de plateau en hexagone
			decalage = getDecalage(i);
			
			/* Placement de toutes les cases du plateau dans le tableau
			 * D�calage d'une case en colonne pour avoir le m�me format que le vrai jeu
			 */
			for (int j=0; j<NB_COL; j++) {
				/* Test pour bien placer les cases jouables et les cases non jouables
				 * Besoin de cases vides pour observer un d�calage sur l'affichage
				 */
				if (((j%2 == 0 && i%2 == 0) || (j%2 == 1 && i%2 == 1)) && (j <= NB_COL - decalage && j >= 0 + decalage)) {
					this.tableauPlateau[i][j] = new Case(TypeCase.VIDE, null);
				} else { 
					this.tableauPlateau[i][j] = new Case(TypeCase.NON_JOUABLE, null);
				}
			}
		}
		
		/* Placement des boules sur le tableau d'affichage
		 * X pour les boules noires
		 * O pour les boules blanches
		 */
		for (int k=0; k<this.listeBoules.size(); k++) {
			
			bouleY = this.listeBoules.get(k).getY();
			bouleX = this.listeBoules.get(k).getX();
			
			bouleX = Conversion.getXFromListeToTableau(bouleX, bouleY);
			
			// Origine du tableau en haut � gauche, donc modification de la coordonn�e Y 
			bouleY = Conversion.getYFromListeToTableau(bouleY);
			
			if (this.listeBoules.get(k).getCouleur() == Color.BLACK) {
				this.tableauPlateau[bouleY][bouleX] = new Case(TypeCase.NON_VIDE, this.listeBoules.get(k));
			} else {
				this.tableauPlateau[bouleY][bouleX] = new Case(TypeCase.NON_VIDE, this.listeBoules.get(k));
			}
			
		}
		
		this.afficher();
		
		
		/*
		 * Tests si boules cr��es aux bons emplacements
		 *
		int nb2 = 0;
		int nb3 = 0;
		int nb4 = 0;
		for (int i=0; i<this.listeBoules.size(); i++) {
			
			if (this.listeBoules.get(i).getPosition().y == 2) {
				nb2++;
			}
			if (this.listeBoules.get(i).getPosition().y == 3) {
				nb3++;
			}
			if (this.listeBoules.get(i).getPosition().y == 4) {
				nb4++;
			}
		}

		System.out.println("2 : "+nb2);
		System.out.println("3 : "+nb3);
		System.out.println("4 : "+nb4);*/
		
	}
	
	/**
	 * Affichage du plateau (variable tableauPlateau)
	 */
	public void afficher() {
	
		for (int i=0; i<NB_COL; i++) {
			if (i==0) {
				System.out.print("  ");
			}
			System.out.print(i + "\t");
			if (i == NB_COL - 1) {
				System.out.println();
			}
		}
		
		for (int i=0; i<NB_LIG; i++) {
			System.out.println();
			for (int j=0; j<NB_COL; j++) {
				if (j==0) {
					System.out.print(i + " ");
				}
				System.out.print(this.tableauPlateau[i][j].toString() + "\t");
				if (j == NB_COL - 1) {
					System.out.println();
				}
			}
		}
	}
	
	/**
	 * Retourne le nombre de cases � d�caler en fonction de la ligne pour former un hexagone
	 * @param num_lig
	 * @return decalage
	 */
	public int getDecalage(int num_lig) {
		
		int decalage = 0;
		
		if (num_lig == 0 || num_lig == 8) {
			decalage = 4;
		} else if (num_lig == 1 || num_lig == 7) {
			decalage = 3;
		} else if (num_lig == 2 || num_lig == 6) {
			decalage = 2;
		} else if (num_lig == 3 ||num_lig == 5) {
			decalage = 1;
		} 

		return decalage;
	}

}
