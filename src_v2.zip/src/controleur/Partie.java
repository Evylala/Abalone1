package controleur;

public class Partie {

	private Joueur joueur1;
	private Joueur joueur2;
	private Joueur joueurCourant;
	private Joueur joueurPrecedent;
	private Plateau plateau;
	
	public Partie(Joueur j1, Joueur j2, Plateau p) {
		this.joueur1 = j1;
		this.joueur2 = j2;
		this.joueurCourant = this.joueur1;
		this.joueurPrecedent = this.joueur2;
		this.plateau = p;
	}
	
	public void lancerPartie() {
		
		this.plateau.initialiserPlateau();
		
		while (!finPartie(this.joueurPrecedent)) {
			this.deplacer();
			this.plateau.afficher();
		}
		
		System.out.println("La partie est termin�e \nLe gagnant est : " + this.joueurPrecedent.getNom());
	}
	
	public void deplacer() {
		this.joueurCourant.deplacer(this.plateau);
	}
	
	public boolean finPartie(Joueur j) {
		if (j.getScore() < 6) {
			return false;
		} else {
			return true;
		}
	}
	
}
