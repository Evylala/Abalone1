package controleur;

public abstract class Joueur {
	
	protected String nom;
	protected int score;
	protected Regles regles;
	
	public Joueur(String nom, Regles regles) {
		this.nom = nom;
		this.score = 0;
		this.regles = regles;
	}
	
	public int getScore() {
		return this.score;
	}
	
	public String getNom() {
		return this.nom;
	}
	
	public Regles getRegles() {
		return this.regles;
	}
	
	public void ajoutPoint() {
		this.score++;
	}
	
	public abstract void deplacer(Plateau p);
	
}
