package controleur;

public enum TypeCase {
	VIDE,
	NON_VIDE,
	NON_JOUABLE
}
