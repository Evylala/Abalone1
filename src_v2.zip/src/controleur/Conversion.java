package controleur;

public class Conversion {
	
	/**
	 * Retourne la coordonn�e x d'une boule (provenant de la liste) pour le tableau d'affichage
	 * @param bouleX
	 * @param bouleY
	 * @return x
	 */
	public static int getXFromListeToTableau(int bouleX, int bouleY) {
		int y = Math.abs(bouleY);
		return (y + bouleX*2);
	}
	
	/**
	 * Retourne la coordonn�e y d'une boule (provenant de la liste) pour le tableau d'affichage
	 * @param bouleY
	 * @return y
	 */
	public static int getYFromListeToTableau(int bouleY) {
		int y = 0;
		
		if (bouleY<0) {
			y = bouleY * (-1) +4;
		} else {
			y = 4 - bouleY;
		}
		
		return y;
	}
	
	/**
	 * Retourne la coordonn�e x de la boule (provenant du tableau) pour les d�placements
	 * @param x
	 * @return int
	 */
	public static int getXFromTableauToListe(int x, int y) {
		int newY = Math.abs(y);
		return (x/2) - (newY/2);
	}
	
	/**
	 * Retourne la coordonn�e y de la boule (provenant du tableau) pour les d�placements
	 * @param y
	 * @return
	 */
	public static int getYFromTableauToListe(int y) {
		int bouleY = 0;
		
		if (y <= 4) {
			bouleY = y - 4;
		} else {
			bouleY = (y - 4)*(-1);
		}
		
		return bouleY;
	}
	
}
