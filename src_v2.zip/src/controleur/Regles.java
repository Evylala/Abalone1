package controleur;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;

public class Regles {
	
	private ArrayList<Boule> listeBoulesExistantes;
	private ArrayList<Boule> listeBoulesADeplacer;
	private ArrayList<Boule> listeBoulesApresDeplacement;
	private Deplacement deplacement;
	private String messageCoupImpossible;
	private Plateau plateau;
	private int deltaX;
	private int deltaY;
	private Color couleurDuJoueur;
	private boolean bouleAdversaireSortie;
	int NB_COL_MAX = 9;
	
	public Regles(Plateau p) {
		this.listeBoulesExistantes = new ArrayList<Boule>();
		this.listeBoulesADeplacer = new ArrayList<Boule>();
		this.listeBoulesApresDeplacement = new ArrayList<Boule>();
		this.deplacement = null;
		this.messageCoupImpossible = "";
		this.deltaX = 0;
		this.deltaY = 0;
		this.plateau = p;
		this.couleurDuJoueur = null;
		this.bouleAdversaireSortie = false;
	}
	
	public ArrayList<Boule> getListeBoulesApresDeplacement() {
		return this.listeBoulesApresDeplacement;
	}
	
	public String getMessageErreur() {
		return this.messageCoupImpossible;
	}
	
	public boolean getBouleAdversaireSortie() {
		return this.bouleAdversaireSortie;
	}
	
	public void setListeBoulesExistantes(ArrayList<Boule> liste) {
		this.listeBoulesExistantes = liste;
	}
	
	public void setListeBoulesADeplacer(ArrayList<Boule> liste) {
		this.listeBoulesADeplacer = liste;
	}
	
	public void setListeBoulesApresDeplacement(ArrayList<Boule> liste) {
		this.listeBoulesApresDeplacement = liste;
	}
	
	public void setDeplacement(Deplacement d) {
		this.deplacement = d;
	}
	
	public void setCouleurDuJoueur(Color c) {
		this.couleurDuJoueur = c;
	}
	
	public void setBouleAdversaireSortie(boolean bouleSortie) {
		this.bouleAdversaireSortie = bouleSortie;
	}
	
	public boolean deplacementEffectue(ArrayList<Boule> listeBoulesExistantes, Boule boule, Deplacement deplacement, int nbBoules) {
		
		this.messageCoupImpossible = "";
		boolean deplacementEffectue = false;
		this.setListeBoulesExistantes(listeBoulesExistantes);
		this.listeBoulesADeplacer.clear();
		this.listeBoulesApresDeplacement.clear();;
		this.setDeplacement(deplacement);
		this.setDeltaXEtDeltaY();
		this.setCouleurDuJoueur(boule.getCouleur());
		this.setBouleAdversaireSortie(false);
		
		
		return !sortDuPlateau(boule) && rapportDeForceOK(boule, nbBoules) && deplacementApplique();
		
		
	}
	
	public boolean sortDuPlateau(Boule boule) {
		int bouleY = boule.getY();
		int bouleX = boule.getX();
		int valAbsBouleY = 0;
		
		valAbsBouleY = Math.abs(bouleY);
		
		if (bouleX < 0 || bouleX > NB_COL_MAX - valAbsBouleY - 1 || bouleY < 0 || bouleY > valAbsBouleY ) {
			return true;
		}
		
		return false;
		
	}
	
	public boolean rapportDeForceOK(Boule boule, int nbBoules) {
		Color couleur = boule.getCouleur();
		int nbCouleur2 = 0;
		Boule boulePrecedente = boule;
		Boule bouleActuelle = null;
		boolean bouleTrouvee = false;
		int taille = 0;
		
		this.listeBoulesADeplacer.add(boule);
		System.out.println("DeltaX : "+this.deltaX);
		
		for (int i=0; i<nbBoules; i++) {
			for (Boule b : this.listeBoulesExistantes) {
				
				if (b.getX() == boulePrecedente.getX() + this.deltaX && b.getY() == boulePrecedente.getY() + this.deltaY) {
					if (b.getCouleur() != couleur) {
						this.messageCoupImpossible = "Vous essayez de d�placer une boule qui ne vous appartient pas, veuillez refaire votre choix.";
						return false;
					} else {
						bouleTrouvee = true;
						boulePrecedente = b;
						this.listeBoulesADeplacer.add(b);
						break;
					}
				}
			}
		}
		
		if (bouleTrouvee) {
			while (bouleTrouvee) {
				taille = this.listeBoulesExistantes.size();
				for (Boule b : this.listeBoulesExistantes) {
					if (nbCouleur2 <= nbBoules) {
						if (b.getPosition().x == boulePrecedente.getPosition().x + this.deltaX && b.getPosition().y == boulePrecedente.getPosition().y + this.deltaY) {
							if (b.getCouleur() == couleur) {
								this.messageCoupImpossible = "Vous essayez de pousser une boule vous appartenant, veuillez refaire votre choix.";
								return false;
							} else {
								this.listeBoulesADeplacer.add(b);
								boulePrecedente = b;
								nbCouleur2++;
								break;
							}
						}
					} else {
						this.messageCoupImpossible = "Pouss�e impossible, veuillez refaire votre choix.";
						return false;
					}
					if (--taille == 0) {
						bouleTrouvee = false;
					}
				}
			}
			
		}
		
		return true;
	}
	
	public boolean deplacementApplique() {
		Boule bouleDeplacee = null;
		Boule derniereBoule = this.listeBoulesADeplacer.get(this.listeBoulesADeplacer.size()-1);
		this.setListeBoulesApresDeplacement(new ArrayList<Boule>());
		int index = 0;
		
		
		for (Boule b : this.listeBoulesADeplacer) {
			bouleDeplacee = new Boule(b.getCouleur(), new Point(b.getX() + this.deltaX, b.getY() + this.deltaY));
			this.listeBoulesApresDeplacement.add(bouleDeplacee);
			index = this.listeBoulesExistantes.indexOf(b);
			this.listeBoulesExistantes.set(index, bouleDeplacee);
		}
		
		if (sortDuPlateau(derniereBoule)) {
			if (derniereBoule.getCouleur() == this.couleurDuJoueur) {
				this.messageCoupImpossible = "L'une de vos boules va sortir du plateau, veuillez refaire votre choix";
				return false;
			} else {
				this.bouleAdversaireSortie = true;
				this.listeBoulesExistantes.remove(derniereBoule);
			}
		}
		
		this.plateau.setListeBoules(this.listeBoulesExistantes);
		
		return true;
		
	}
	
	public void setDeltaXEtDeltaY() {
		
		switch(this.deplacement) {
			case HAUT_GAUCHE:
				this.deltaX = -1;
				this.deltaY = 1;
				break;
			case HAUT_DROIT:
				this.deltaX = 0;
				this.deltaY = 1;
				break;
			case GAUCHE:
				this.deltaX = -1;
				this.deltaY = 0;
				break;
			case DROITE:
				this.deltaX = 1;
				this.deltaY = 0;
				break;
			case BAS_GAUCHE:
				this.deltaX = -1;
				this.deltaY = -1;
				break;
			case BAS_DROIT:
				this.deltaX = 0;
				this.deltaY = -1;
				break;
		}
		
	}
	

}
