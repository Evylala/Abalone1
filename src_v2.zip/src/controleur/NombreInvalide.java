package controleur;

public class NombreInvalide extends Exception {
	
	public String toString() {
		return "Le nombre que vous avez entr� est invalide";
	}
}
