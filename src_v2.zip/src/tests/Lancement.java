package tests;

import controleur.*;

public class Lancement {
	
	public static void main(String[] args) {
		Plateau plateau = new Plateau();
		Regles regles = new Regles(plateau);
		
		Joueur homme = new Homme("Evy", regles);
		Joueur machine = new Machine("GrosTest", regles);
		
		
		Partie partie = new Partie(homme, machine, plateau);
		
		System.out.println("---------------------------------------- Bienvenue sur le jeu Abalone ------------------------------------------\n\n");
		System.out.println("Vous poss�dez les boules \"O\"\n\n ");
		
		partie.lancerPartie();
		
	}
}
