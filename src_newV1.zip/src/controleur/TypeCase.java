package controleur;

public enum TypeCase {
	VIDE,
	BOULE_BLANCHE,
	BOULE_NOIRE,
}
