package controleur;

public enum TypeDirection {
	HAUT_GAUCHE,
	HAUT_DROIT,
	DROITE,
	GAUCHE,
	BAS_GAUCHE,
	BAS_DROIT
}
