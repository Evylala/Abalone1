package controleur;

public class Machine extends Joueur {
	
	public Machine (String nom, Deplacement deplLigne, Deplacement deplFleche) {
		super(nom, deplLigne, deplFleche);
	}

	@Override
	public void deplacer(Plateau p) {
	}
}
